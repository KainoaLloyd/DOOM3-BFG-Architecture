---
layout: page
title: Assignments
---

## Conceptual Architecture

* ###[Conceptual Architecture Presentation]({{ site.github.repo }}{{ site.github.branch }}Assignments/A1/Basement-Gurus-Doom-3-BFG-Conceptual-Architecture-Presentation.pdf)

* ###[Conceptual Architecture Report]({{ site.github.repo }}{{ site.github.branch }}Assignments/A1/Basement-Gurus-Doom-3-BFG-Coneceptual-Architecture-Report.pdf)

## Concrete Architecture

* ###[Concrete Architecture Presentation]({{ site.github.repo }}{{ site.github.branch }}Assignments/A2/Basement-Gurus-Doom-3-BFG-Concrete-Architecture-Presentation.pdf)

* ###[Concrete Architecture Report]({{ site.github.repo }}{{ site.github.branch }}Assignments/A2/Basement-Gurus-Doom-3-BFG-Concrete-Architecture-Report.pdf)

## Enhancement Proposal: H.U.D Map

* ### [Enhancement Proposal Presentation]({{ site.github.repo }}{{ site.github.branch }}Assignments/A3/Basement-Gurus-Doom-3-BFG-Enhancement-Proposal-Presentation.pdf)

* ### [Enhancement Proposal Report]({{ site.github.repo }}{{ site.github.branch }}Assignments/A3/Basement-Gurus-Doom-3-BFG-Enhancement-Proposal-Report.pdf)
