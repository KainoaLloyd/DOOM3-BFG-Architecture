---
layout: page
title: Team Information
---

# Team Basement Gurus


## Team Members
* Isaac Chan
* Daniel Elmer
* Matthew Sherar
* Yohanna Gadelrab
* Dylan Liu
* Kainoa Lloyd


### Contact Person
* Kainoa Lloyd - **13krl1 [AT] queensu [DOT] ca**
